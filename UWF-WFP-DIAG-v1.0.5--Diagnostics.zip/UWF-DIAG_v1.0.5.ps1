﻿#requires -Version 5.1
<#
Universal Windows Firewall Diagnostic (UWF-DIAG) v1.0.5
System-wide WFP correlation plus Microsoft Unified Write Filter (UWF) diagnostics.
Read-only: does not change audit policy, firewall rules, UWF settings, services, routes, registry, or WFP settings.
Run elevated for the fullest evidence collection.
#>
[CmdletBinding()]
param(
    [string]$OutputRoot = (Join-Path $env:USERPROFILE 'Desktop\UWF-DIAG-Reports'),
    [ValidateRange(1,720)][int]$LookbackHours = 24,
    [ValidateRange(100,50000)][int]$MaxAuditEvents = 10000,
    [ValidateRange(100,20000)][int]$MaxUwfEvents = 2000,
    [switch]$IncludeAllFirewallRules,
    [switch]$RunNetworkTests
)

$ErrorActionPreference = 'Continue'
$script:Report = New-Object 'System.Collections.Generic.List[string]'
$script:OutDir = $null

function Add-Line {
    param([AllowNull()][object]$Value)
    if ($null -eq $Value) { [void]$script:Report.Add('') }
    else { [void]$script:Report.Add([string]$Value) }
}
function Add-Section {
    param([string]$Title)
    Write-Host ''
    Write-Host ('=' * 78) -ForegroundColor DarkCyan
    Write-Host $Title -ForegroundColor Cyan
    Write-Host ('=' * 78) -ForegroundColor DarkCyan
    Add-Line ''
    Add-Line ('=' * 78)
    Add-Line $Title
    Add-Line ('=' * 78)
}
function Save-Csv {
    param([string]$Name, [AllowNull()][object]$Data)
    try {
        if ($null -eq $Data) { return }
        # Do not use @($Data) here: Windows PowerShell 5.1 can throw
        # ArgumentException when @() wraps a New-Object List[object].
        $hasRows = $true
        if ($Data -is [System.Collections.ICollection]) {
            $hasRows = ($Data.Count -gt 0)
        }
        if ($hasRows) {
            $Data | Export-Csv -LiteralPath (Join-Path $script:OutDir $Name) -NoTypeInformation -Encoding UTF8
        }
    } catch { Add-Line "CSV export failed ($Name): $($_.Exception.Message)" }
}
function Test-Administrator {
    try {
        $identity = [Security.Principal.WindowsIdentity]::GetCurrent()
        $principal = New-Object Security.Principal.WindowsPrincipal($identity)
        return $principal.IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)
    } catch { return $false }
}
function ConvertTo-UInt64Text {
    param([AllowNull()][object]$Value)
    if ($null -eq $Value) { return '' }
    $s = ([string]$Value).Trim()
    if (-not $s) { return '' }
    if ($s -match '^0x([0-9a-fA-F]+)$') {
        try { return ([Convert]::ToUInt64($Matches[1], 16)).ToString() } catch { return $s }
    }
    [UInt64]$number = 0
    if ([UInt64]::TryParse($s, [ref]$number)) { return $number.ToString() }
    return $s
}
function Get-XmlDirectText {
    param([System.Xml.XmlNode]$Node, [string]$ChildName)
    if ($null -eq $Node) { return '' }
    $child = $Node.SelectSingleNode("./*[local-name()='$ChildName']")
    if ($null -eq $child) { return '' }
    return $child.InnerText.Trim()
}
function Get-XmlDisplayName {
    param([System.Xml.XmlNode]$Node)
    if ($null -eq $Node) { return '' }
    $display = $Node.SelectSingleNode("./*[local-name()='displayData']")
    return (Get-XmlDirectText -Node $display -ChildName 'name')
}
function Get-EventDataMap {
    param($EventRecord)
    $map = @{}
    try {
        [xml]$doc = $EventRecord.ToXml()
        $nodes = $doc.SelectNodes("//*[local-name()='EventData']/*[local-name()='Data']")
        foreach ($node in $nodes) {
            $name = $node.GetAttribute('Name')
            if ($name) { $map[$name] = $node.InnerText.Trim() }
        }
    } catch { }
    return $map
}
function Get-FirstDataValue {
    param([hashtable]$Map, [string[]]$Names)
    foreach ($name in $Names) {
        if ($Map.ContainsKey($name) -and -not [string]::IsNullOrWhiteSpace([string]$Map[$name])) {
            return [string]$Map[$name]
        }
    }
    return ''
}
function Get-ProcessKind {
    param([string]$PidText, [string]$Application, $CurrentProcess)
    $pidNormalized = ConvertTo-UInt64Text $PidText
    if ($pidNormalized -eq '4' -or $Application -match '(?i)(^|[\\/])?System$') { return 'System' }
    if ($Application) { return [IO.Path]::GetFileName($Application) }
    if ($null -ne $CurrentProcess -and $CurrentProcess.Name) { return [string]$CurrentProcess.Name }
    return 'Process name unavailable'
}
function Get-ProtocolName {
    param([string]$Protocol)
    switch ($Protocol) {
        '1' { 'ICMP' }
        '6' { 'TCP' }
        '17' { 'UDP' }
        '47' { 'GRE' }
        '50' { 'ESP' }
        '51' { 'AH' }
        default { $Protocol }
    }
}
function Get-WfpFilterRecords {
    param([string[]]$Paths)
    $rows = New-Object 'System.Collections.Generic.List[object]'
    $docs = New-Object 'System.Collections.Generic.List[object]'
    $providerNames = @{}
    $layerNames = @{}
    $subLayerNames = @{}
    foreach ($path in $Paths) {
        if (-not (Test-Path -LiteralPath $path)) { continue }
        try {
            $raw = Get-Content -LiteralPath $path -Raw -ErrorAction Stop
            # netsh WFP state can contain multiple top-level sections. Wrap fragments.
            $raw = $raw -replace '^\s*<\?xml[^>]*\?>', ''
            $doc = New-Object System.Xml.XmlDocument
            $doc.LoadXml('<UWFROOT>' + $raw + '</UWFROOT>')
            $docs.Add([pscustomobject]@{Path=$path; Xml=$doc})
        } catch { Add-Line "Could not load WFP XML $path : $($_.Exception.Message)" }
    }
    # First pass: build provider/layer/sublayer dictionaries across BOTH exports.
    foreach ($entry in $docs) {
        foreach ($sectionName in @('providers','layers','subLayers')) {
            foreach ($section in $entry.Xml.SelectNodes("//*[local-name()='$sectionName']")) {
                foreach ($item in $section.SelectNodes("./*[local-name()='item']")) {
                    $keyName = switch ($sectionName) { 'providers' {'providerKey'} 'layers' {'layerKey'} 'subLayers' {'subLayerKey'} }
                    $keyValue = Get-XmlDirectText -Node $item -ChildName $keyName
                    $display = Get-XmlDisplayName -Node $item
                    if ($keyValue -and $display) {
                        switch ($sectionName) {
                            'providers' { $providerNames[$keyValue] = $display }
                            'layers' { $layerNames[$keyValue] = $display }
                            'subLayers' { $subLayerNames[$keyValue] = $display }
                        }
                    }
                }
            }
        }
    }
    # Second pass: parse filters/item (actual netsh format), with legacy fallback.
    $seen = @{}
    foreach ($entry in $docs) {
        $filterNodes = $entry.Xml.SelectNodes("//*[local-name()='filters']/*[local-name()='item']")
        if ($filterNodes.Count -eq 0) { $filterNodes = $entry.Xml.SelectNodes("//*[local-name()='filter']") }
        foreach ($node in $filterNodes) {
            $filterId = Get-XmlDirectText -Node $node -ChildName 'filterId'
            $filterKey = Get-XmlDirectText -Node $node -ChildName 'filterKey'
            $filterName = Get-XmlDisplayName -Node $node
            $providerKey = Get-XmlDirectText -Node $node -ChildName 'providerKey'
            $layerKey = Get-XmlDirectText -Node $node -ChildName 'layerKey'
            $subLayerKey = Get-XmlDirectText -Node $node -ChildName 'subLayerKey'
            $actionNode = $node.SelectSingleNode("./*[local-name()='action']")
            $actionType = Get-XmlDirectText -Node $actionNode -ChildName 'type'
            if (-not $actionType -and $null -ne $actionNode) { $actionType = $actionNode.InnerText.Trim() }
            $conditionNode = $node.SelectSingleNode("./*[local-name()='filterCondition']")
            $conditionText = ''
            if ($null -ne $conditionNode) {
                $conditionText = ($conditionNode.InnerText -replace '\s+', ' ').Trim()
                if ($conditionText.Length -gt 3000) { $conditionText = $conditionText.Substring(0,3000) + ' ...[truncated]' }
            }
            if ($filterId -or $filterKey -or $filterName) {
                $normalizedId = ConvertTo-UInt64Text $filterId
                $dedupeKey = "$normalizedId|$filterKey"
                if (-not $normalizedId -and -not $filterKey) { $dedupeKey = "$providerKey|$filterName|$layerKey" }
                if (-not $seen.ContainsKey($dedupeKey)) {
                    $seen[$dedupeKey] = $true
                    $rows.Add([pscustomobject]@{
                        SourceDump=[IO.Path]::GetFileName($entry.Path); FilterId=$filterId
                        FilterIdNormalized=$normalizedId; FilterKey=$filterKey; FilterName=$filterName
                        ProviderKey=$providerKey; ProviderName=$(if ($providerNames.ContainsKey($providerKey)) {$providerNames[$providerKey]} else {''})
                        LayerKey=$layerKey; LayerName=$(if ($layerNames.ContainsKey($layerKey)) {$layerNames[$layerKey]} else {''})
                        SubLayerKey=$subLayerKey; SubLayerName=$(if ($subLayerNames.ContainsKey($subLayerKey)) {$subLayerNames[$subLayerKey]} else {''})
                        ActionType=$actionType; Conditions=$conditionText
                    })
                }
            }
        }
    }
    return $rows.ToArray()
}


# The CMD launcher handles UAC elevation. Avoid spawning a second PowerShell
# console here; direct non-elevated invocation exits with an explicit instruction.
if (-not (Test-Administrator)) {
    Write-Host 'ERROR: Administrator privileges are required.' -ForegroundColor Red
    Write-Host 'Run Run-UWF-DIAG_v1.0.5.cmd; the launcher will request elevation and show progress.' -ForegroundColor Yellow
    exit 5
}

# Create a unique report folder.
$timestamp = Get-Date -Format 'yyyyMMdd_HHmmss'
try {
    New-Item -ItemType Directory -Path $OutputRoot -Force | Out-Null
    $script:OutDir = Join-Path $OutputRoot "UWF-DIAG_$timestamp"
    New-Item -ItemType Directory -Path $script:OutDir -Force | Out-Null
} catch {
    Write-Error "Cannot create output folder: $($_.Exception.Message)"
    exit 2
}

$isAdmin = Test-Administrator
$collectionStart = Get-Date
$transcriptPath = Join-Path $script:OutDir 'UWF-DIAG_Console.log'
try { Start-Transcript -Path $transcriptPath -Force | Out-Null } catch { }
Write-Host ''
Write-Host 'Universal Windows Firewall Diagnostic (UWF-DIAG) v1.0.5' -ForegroundColor Green
Write-Host 'Read-only collection. Live progress appears below.' -ForegroundColor Gray
Write-Host "Report folder: $script:OutDir" -ForegroundColor Gray
Add-Line 'Universal Windows Firewall Diagnostic (UWF-DIAG) v1.0.5'
Add-Line "Generated: $($collectionStart.ToString('yyyy-MM-dd HH:mm:ss zzz'))"
Add-Line "Computer: $env:COMPUTERNAME"
Add-Line "Elevated: $isAdmin"
Add-Line "Audit lookback: $LookbackHours hour(s)"
Add-Line 'Mode: READ-ONLY. No firewall, audit, WFP, UWF, service, route, registry, or network settings are changed.'
Add-Line "Output: $script:OutDir"
if (-not $isAdmin) { Add-Line 'WARNING: Not elevated. Some Security events, WFP details, and process metadata may be unavailable.' }

# 1. OS identity
Add-Section '1. SYSTEM IDENTIFICATION'
$os = Get-CimInstance Win32_OperatingSystem -ErrorAction SilentlyContinue
$cs = Get-CimInstance Win32_ComputerSystem -ErrorAction SilentlyContinue
$osRow = [pscustomobject]@{
    ComputerName = $env:COMPUTERNAME
    Caption = $os.Caption
    Version = $os.Version
    BuildNumber = $os.BuildNumber
    Architecture = $os.OSArchitecture
    Manufacturer = $cs.Manufacturer
    Model = $cs.Model
    PowerShellVersion = $PSVersionTable.PSVersion.ToString()
    PowerShellEdition = $PSVersionTable.PSEdition
    Elevated = $isAdmin
}
$osRow | Format-List | Out-String | ForEach-Object { Add-Line $_ }
Save-Csv 'System.csv' @($osRow)

# 2. Effective firewall profiles and current rules
Add-Section '2. EFFECTIVE FIREWALL PROFILES'
$profiles = @(Get-NetFirewallProfile -PolicyStore ActiveStore -ErrorAction SilentlyContinue)
if ($profiles.Count) {
    $profiles | Select-Object Name,Enabled,DefaultInboundAction,DefaultOutboundAction,AllowLocalFirewallRules,AllowLocalIPsecRules,LogBlocked,LogAllowed,LogFileName | Format-Table -AutoSize | Out-String -Width 240 | ForEach-Object { Add-Line $_ }
    Save-Csv 'FirewallProfiles.csv' $profiles
} else { Add-Line 'Firewall profile data unavailable.' }

Add-Section '3. ACTIVE FIREWALL RULE INVENTORY'
if ($IncludeAllFirewallRules) { $rules = @(Get-NetFirewallRule -PolicyStore ActiveStore -ErrorAction SilentlyContinue) }
else { $rules = @(Get-NetFirewallRule -PolicyStore ActiveStore -Enabled True -ErrorAction SilentlyContinue) }
$ruleRows = foreach ($rule in $rules) {
    [pscustomobject]@{
        DisplayName=$rule.DisplayName; Name=$rule.Name; Enabled=$rule.Enabled; Direction=$rule.Direction
        Action=$rule.Action; Profile=$rule.Profile; PolicyStoreSourceType=$rule.PolicyStoreSourceType
        PolicyStoreSource=$rule.PolicyStoreSource; Group=$rule.Group
    }
}
Save-Csv 'FirewallRules.csv' $ruleRows
$outboundBlocks = @($ruleRows | Where-Object { $_.Direction -eq 'Outbound' -and $_.Action -eq 'Block' -and [string]$_.Enabled -eq 'True' })
Add-Line "Rules collected: $(@($ruleRows).Count)"
Add-Line "Enabled outbound block rules: $($outboundBlocks.Count)"
$outboundBlocks | Format-Table DisplayName,Name,Profile,PolicyStoreSourceType -AutoSize | Out-String -Width 220 | ForEach-Object { Add-Line $_ }

# 4. Process and service inventory for historical PID context
Add-Section '4. ALL-PROCESS AND WINDOWS SERVICE INVENTORY'
$processes = @(Get-CimInstance Win32_Process -ErrorAction SilentlyContinue)
$services = @(Get-CimInstance Win32_Service -ErrorAction SilentlyContinue)
$processById = @{}
foreach ($proc in $processes) { $processById[[string]$proc.ProcessId] = $proc }
$servicesByPid = @{}
foreach ($svc in $services) {
    $key = [string]$svc.ProcessId
    if ($svc.ProcessId -gt 0) {
        if (-not $servicesByPid.ContainsKey($key)) { $servicesByPid[$key] = New-Object 'System.Collections.Generic.List[string]' }
        [void]$servicesByPid[$key].Add("$($svc.Name) [$($svc.State)]")
    }
}
$targetProcessRows = New-Object 'System.Collections.Generic.List[object]'
foreach ($proc in $processes | Where-Object { $_.ProcessId -eq 4 -or $_.Name -ieq 'svchost.exe' }) {
    $svcText = ''
    if ($servicesByPid.ContainsKey([string]$proc.ProcessId)) { $svcText = ($servicesByPid[[string]$proc.ProcessId] -join '; ') }
    $targetProcessRows.Add([pscustomobject]@{
        ProcessId=$proc.ProcessId; Name=$proc.Name; ExecutablePath=$proc.ExecutablePath
        CommandLine=$proc.CommandLine; HostedServices=$svcText
    })
}
$targetProcessRows | Format-Table ProcessId,Name,ExecutablePath,HostedServices -AutoSize | Out-String -Width 240 | ForEach-Object { Add-Line $_ }
Save-Csv 'System_Svchost_CurrentProcesses.csv' $targetProcessRows
$allProcessRows = New-Object 'System.Collections.Generic.List[object]'
foreach ($proc in $processes) {
    $svcText = ''
    if ($servicesByPid.ContainsKey([string]$proc.ProcessId)) { $svcText = ($servicesByPid[[string]$proc.ProcessId] -join '; ') }
    $allProcessRows.Add([pscustomobject]@{ ProcessId=$proc.ProcessId; ParentProcessId=$proc.ParentProcessId; Name=$proc.Name; ExecutablePath=$proc.ExecutablePath; CommandLine=$proc.CommandLine; HostedServices=$svcText })
}
Save-Csv 'ProcessInventory_All.csv' $allProcessRows
$serviceRows = foreach ($svc in $services) { [pscustomobject]@{Name=$svc.Name; DisplayName=$svc.DisplayName; State=$svc.State; StartMode=$svc.StartMode; ProcessId=$svc.ProcessId; PathName=$svc.PathName; StartName=$svc.StartName} }
Save-Csv 'ServiceInventory_All.csv' $serviceRows
Add-Line "All current processes inventoried: $($allProcessRows.Count)"
Add-Line "All Windows services inventoried: $(@($serviceRows).Count)"
Add-Line "Current svchost.exe processes found: $(@($targetProcessRows | Where-Object { $_.Name -ieq 'svchost.exe' }).Count)"
Add-Line 'System is represented by PID 4; its executable path may be blank by design.'

# 5. Read-only audit policy status
Add-Section '5. WFP AUDIT POLICY STATUS (READ-ONLY)'
$auditConnection = @(& auditpol.exe /get /subcategory:'Filtering Platform Connection' 2>&1)
$auditPacket = @(& auditpol.exe /get /subcategory:'Filtering Platform Packet Drop' 2>&1)
Add-Line 'Filtering Platform Connection:'
$auditConnection | ForEach-Object { Add-Line $_ }
Add-Line 'Filtering Platform Packet Drop:'
$auditPacket | ForEach-Object { Add-Line $_ }
($auditConnection + @('') + $auditPacket) | Set-Content -LiteralPath (Join-Path $script:OutDir 'AuditPolicy_ReadOnly.txt') -Encoding UTF8

# 6. Snapshot WFP state and filter dump
Add-Section '6. WFP STATE AND FILTER EXPORT'
Write-Host '[WFP] Exporting WFP state and filters. This stage may take a little while...' -ForegroundColor Yellow
$netsh = Join-Path $env:SystemRoot 'System32\netsh.exe'
$wfpStatePath = Join-Path $script:OutDir 'WFP_State.xml'
$wfpFiltersPath = Join-Path $script:OutDir 'WFP_Filters.xml'
try {
    $stateOutput = @(& $netsh wfp show state "file=$wfpStatePath" 2>&1)
    $stateExit = $LASTEXITCODE
    $stateOutput | Out-String | Set-Content -LiteralPath (Join-Path $script:OutDir 'WFP_State_Command.txt') -Encoding UTF8
    Add-Line "netsh wfp show state exit code: $stateExit"
    Add-Line "WFP state XML exists: $(Test-Path -LiteralPath $wfpStatePath)"
} catch { Add-Line "WFP state export failed: $($_.Exception.Message)" }
try {
    $filterOutput = @(& $netsh wfp show filters "file=$wfpFiltersPath" verbose=on 2>&1)
    $filterExit = $LASTEXITCODE
    $filterOutput | Out-String | Set-Content -LiteralPath (Join-Path $script:OutDir 'WFP_Filters_Command.txt') -Encoding UTF8
    Add-Line "netsh wfp show filters exit code: $filterExit"
    Add-Line "WFP filters XML exists: $(Test-Path -LiteralPath $wfpFiltersPath)"
} catch { Add-Line "WFP filters export failed: $($_.Exception.Message)" }
Write-Host '[WFP] Parsing exported XML filter records...' -ForegroundColor Yellow
$wfpFilters = @(Get-WfpFilterRecords -Paths @($wfpStatePath,$wfpFiltersPath))
Save-Csv 'WFP_FilterInventory.csv' $wfpFilters
Add-Line "WFP filter records parsed: $($wfpFilters.Count)"
if ($wfpFilters.Count -eq 0) { Add-Line 'WARNING: No WFP filter records were parsed. Keep the raw XML exports and treat runtime-ID attribution as unavailable.' }
Write-Host "[WFP] Export and parse finished. Parsed filters: $($wfpFilters.Count)" -ForegroundColor Green

# 7. Collect WFP block events, enrich with WFP filter IDs, Filter Origin, interface and service context.
Add-Section '7. ALL-PROCESS WFP BLOCK EVENTS (5152 / 5157)'
Write-Host "[Security log] Searching events 5152/5157 from the last $LookbackHours hour(s)..." -ForegroundColor Yellow
$since = (Get-Date).AddHours(-$LookbackHours)
$events = @()
try {
    $events = @(Get-WinEvent -FilterHashtable @{ LogName='Security'; Id=@(5152,5157); StartTime=$since } -MaxEvents $MaxAuditEvents -ErrorAction Stop)
} catch {
    Add-Line "Security audit query returned no events or could not be read: $($_.Exception.Message)"
}
Add-Line "Search start: $($since.ToString('yyyy-MM-dd HH:mm:ss zzz'))"
Add-Line "Block events retrieved: $($events.Count)"
Write-Host "[Security log] Retrieved $($events.Count) block event(s)." -ForegroundColor Green

# Build a best-effort filter-ID lookup from the current WFP snapshots.
$filterById = @{}
foreach ($filter in $wfpFilters) {
    $key = [string]$filter.FilterIdNormalized
    if ($key -and $key -ne '0') {
        if (-not $filterById.ContainsKey($key)) { $filterById[$key] = $filter }
        elseif ((-not $filterById[$key].FilterName) -and $filter.FilterName) { $filterById[$key] = $filter }
    }
}

$allEventRows = New-Object 'System.Collections.Generic.List[object]'
$targetEventRows = New-Object 'System.Collections.Generic.List[object]'
$filterOriginRows = New-Object 'System.Collections.Generic.List[object]'
$originRuleCache = @{}
foreach ($event in $events) {
    $data = Get-EventDataMap -EventRecord $event
    $pidRaw = Get-FirstDataValue -Map $data -Names @('ProcessId','ProcessID')
    $pidNormalized = ConvertTo-UInt64Text $pidRaw
    $application = Get-FirstDataValue -Map $data -Names @('Application','ApplicationName')
    $currentProc = $null
    if ($pidNormalized -and $processById.ContainsKey($pidNormalized)) { $currentProc = $processById[$pidNormalized] }
    $kind = Get-ProcessKind -PidText $pidRaw -Application $application -CurrentProcess $currentProc
    $filterRtid = Get-FirstDataValue -Map $data -Names @('FilterRTID','FilterRunTimeID','FilterRuntimeId')
    $filterIdKey = ConvertTo-UInt64Text $filterRtid
    $filterOrigin = Get-FirstDataValue -Map $data -Names @('FilterOrigin','Filter Origin','FilterOriginName')
    $interfaceIndex = Get-FirstDataValue -Map $data -Names @('InterfaceIndex','Interface Index')
    $matched = $null
    if ($filterIdKey -and $filterIdKey -ne '0' -and $filterById.ContainsKey($filterIdKey)) { $matched = $filterById[$filterIdKey] }
    $hostedServices = ''
    $currentCommandLine = ''
    $currentImage = ''
    if ($null -ne $currentProc) {
        $currentCommandLine = [string]$currentProc.CommandLine
        $currentImage = [string]$currentProc.ExecutablePath
        if ($servicesByPid.ContainsKey([string]$currentProc.ProcessId)) { $hostedServices = ($servicesByPid[[string]$currentProc.ProcessId] -join '; ') }
    }
    $originClass = 'Not supplied by this audit event'
    if ($filterOrigin -and $filterOrigin -notmatch '(?i)^unknown$') {
        if ($filterOrigin -match '(?i)default|stealth|quarantine|boot.?time|app.?container|WSH|UWP') { $originClass = 'Firewall/WFP default filter origin' }
        else { $originClass = 'Rule or named filter origin' }
    }
    $originRuleName = ''
    $originRuleAction = ''
    $originRuleDirection = ''
    $originRuleEnabled = ''
    if ($filterOrigin -and $filterOrigin -notmatch '(?i)^unknown$' -and $originClass -eq 'Rule or named filter origin') {
        if (-not $originRuleCache.ContainsKey($filterOrigin)) {
            $foundRules = @()
            if ($filterOrigin -match '^[A-Za-z0-9_{}.-]{1,256}$') { try { $foundRules = @(Get-NetFirewallRule -Name $filterOrigin -PolicyStore ActiveStore -ErrorAction SilentlyContinue) } catch { } }
            if (-not $foundRules.Count) {
                $foundRules = @($rules | Where-Object { $_.Name -ieq $filterOrigin -or $_.DisplayName -ieq $filterOrigin })
            }
            $originRuleCache[$filterOrigin] = $foundRules
        }
        $resolved = @($originRuleCache[$filterOrigin])
        if ($resolved.Count) {
            foreach ($r in $resolved) {
                $appFilter = $null; $portFilter = $null; $addressFilter = $null; $serviceFilter = $null
                try { $appFilter = Get-NetFirewallApplicationFilter -AssociatedNetFirewallRule $r -ErrorAction SilentlyContinue | Select-Object -First 1 } catch { }
                try { $portFilter = Get-NetFirewallPortFilter -AssociatedNetFirewallRule $r -ErrorAction SilentlyContinue | Select-Object -First 1 } catch { }
                try { $addressFilter = Get-NetFirewallAddressFilter -AssociatedNetFirewallRule $r -ErrorAction SilentlyContinue | Select-Object -First 1 } catch { }
                try { $serviceFilter = Get-NetFirewallServiceFilter -AssociatedNetFirewallRule $r -ErrorAction SilentlyContinue | Select-Object -First 1 } catch { }
                $originRuleRows = [pscustomobject]@{
                    EventTime=$event.TimeCreated; EventId=$event.Id; FilterOrigin=$filterOrigin
                    RuleName=$r.Name; DisplayName=$r.DisplayName; Enabled=$r.Enabled; Direction=$r.Direction
                    Action=$r.Action; Profile=$r.Profile; PolicyStoreSourceType=$r.PolicyStoreSourceType
                    PolicyStoreSource=$r.PolicyStoreSource; Program=$(if ($appFilter) { $appFilter.Program } else { '' })
                    Package=$(if ($appFilter) { $appFilter.Package } else { '' })
                    Service=$(if ($serviceFilter) { $serviceFilter.Service } else { '' })
                    Protocol=$(if ($portFilter) { $portFilter.Protocol } else { '' })
                    LocalPort=$(if ($portFilter) { (@($portFilter.LocalPort) -join ',') } else { '' })
                    RemotePort=$(if ($portFilter) { (@($portFilter.RemotePort) -join ',') } else { '' })
                    LocalAddress=$(if ($addressFilter) { (@($addressFilter.LocalAddress) -join ',') } else { '' })
                    RemoteAddress=$(if ($addressFilter) { (@($addressFilter.RemoteAddress) -join ',') } else { '' })
                }
                $filterOriginRows.Add($originRuleRows)
            }
            $originRuleName = ($resolved | ForEach-Object { $_.DisplayName } | Where-Object { $_ }) -join '; '
            $originRuleAction = ($resolved | ForEach-Object { $_.Action } | Where-Object { $_ }) -join '; '
            $originRuleDirection = ($resolved | ForEach-Object { $_.Direction } | Where-Object { $_ }) -join '; '
            $originRuleEnabled = ($resolved | ForEach-Object { $_.Enabled } | Where-Object { $_ }) -join '; '
            $originClass = 'Firewall rule resolved'
        } else { $originClass = 'Named origin not resolved to ActiveStore rule' }
    }
    $correlationStatus = 'No runtime filter ID in event'
    if ($filterIdKey -and $filterIdKey -ne '0') {
        if ($matched) { $correlationStatus = 'Runtime ID matched current WFP export (best-effort)' }
        else { $correlationStatus = 'Runtime ID not found in current WFP export' }
    }
    if ($filterOrigin) { $correlationStatus = "$correlationStatus; Filter Origin present" }
    $row = [pscustomobject]@{
        TimeCreated=$event.TimeCreated; EventId=$event.Id; RecordId=$event.RecordId
        ProcessKind=$kind; ProcessId=$pidNormalized; ProcessIdRaw=$pidRaw
        Application=$application; CurrentImagePath=$currentImage; CurrentCommandLine=$currentCommandLine
        HostedServices=$hostedServices; Direction= (Get-FirstDataValue -Map $data -Names @('Direction'))
        SourceAddress=(Get-FirstDataValue -Map $data -Names @('SourceAddress'))
        SourcePort=(Get-FirstDataValue -Map $data -Names @('SourcePort'))
        DestinationAddress=(Get-FirstDataValue -Map $data -Names @('DestAddress','DestinationAddress'))
        DestinationPort=(Get-FirstDataValue -Map $data -Names @('DestPort','DestinationPort'))
        Protocol=(Get-FirstDataValue -Map $data -Names @('Protocol'))
        ProtocolName=(Get-ProtocolName (Get-FirstDataValue -Map $data -Names @('Protocol')))
        FilterOrigin=$filterOrigin; FilterOriginClass=$originClass; InterfaceIndex=$interfaceIndex
        FirewallRuleDisplayName=$originRuleName; FirewallRuleAction=$originRuleAction
        FirewallRuleDirection=$originRuleDirection; FirewallRuleEnabled=$originRuleEnabled
        FilterRTID=$filterRtid; FilterRTIDNormalized=$filterIdKey
        MatchedWfpFilterName=$(if ($matched) { $matched.FilterName } else { '' })
        MatchedWfpFilterKey=$(if ($matched) { $matched.FilterKey } else { '' })
        MatchedWfpProviderKey=$(if ($matched) { $matched.ProviderKey } else { '' })
        MatchedWfpProviderName=$(if ($matched) { $matched.ProviderName } else { '' })
        MatchedWfpLayerKey=$(if ($matched) { $matched.LayerKey } else { '' })
        MatchedWfpLayerName=$(if ($matched) { $matched.LayerName } else { '' })
        MatchedWfpSubLayerKey=$(if ($matched) { $matched.SubLayerKey } else { '' })
        MatchedWfpSubLayerName=$(if ($matched) { $matched.SubLayerName } else { '' })
        MatchedWfpAction=$(if ($matched) { $matched.ActionType } else { '' })
        MatchedWfpConditions=$(if ($matched) { $matched.Conditions } else { '' })
        LayerName=(Get-FirstDataValue -Map $data -Names @('LayerName'))
        LayerRTID=(Get-FirstDataValue -Map $data -Names @('LayerRTID'))
        CorrelationStatus=$correlationStatus
    }
    $allEventRows.Add($row)
    if ($kind -eq 'System' -or $kind -eq 'svchost.exe') { $targetEventRows.Add($row) }
}
# Resolve interface indexes to friendly aliases for each event when possible.
$interfaceRows = @()
$interfaceByIndex = @{}
try { $interfaceRows = @(Get-NetIPInterface -ErrorAction Stop | Select-Object InterfaceIndex,InterfaceAlias,AddressFamily,ConnectionState,InterfaceMetric) } catch { }
foreach ($iface in $interfaceRows) { $interfaceByIndex[[string]$iface.InterfaceIndex] = [string]$iface.InterfaceAlias }
foreach ($eventRow in $allEventRows) {
    $alias = ''
    if ($eventRow.InterfaceIndex -and $interfaceByIndex.ContainsKey([string]$eventRow.InterfaceIndex)) { $alias = $interfaceByIndex[[string]$eventRow.InterfaceIndex] }
    Add-Member -InputObject $eventRow -MemberType NoteProperty -Name InterfaceAlias -Value $alias -Force
}
Save-Csv 'WFP_BlockEvents_All.csv' $allEventRows
Save-Csv 'WFP_AllProcess_BlockCorrelation.csv' $allEventRows
Save-Csv 'WFP_System_Svchost_Correlation.csv' $targetEventRows
Save-Csv 'WFP_FilterOrigin_RuleDetails.csv' $filterOriginRows
$providerAnalysis = foreach ($g in ($allEventRows | Group-Object MatchedWfpProviderKey,MatchedWfpFilterName,MatchedWfpAction)) {
    $first = $g.Group | Select-Object -First 1
    [pscustomobject]@{ProviderKey=$first.MatchedWfpProviderKey; ProviderName=($(($wfpFilters | Where-Object {$_.ProviderKey -eq $first.MatchedWfpProviderKey} | Select-Object -First 1).ProviderName)); FilterName=$first.MatchedWfpFilterName; Action=$first.MatchedWfpAction; EventCount=$g.Count; DistinctProcesses=@($g.Group | Select-Object -ExpandProperty ProcessId -Unique).Count; DistinctDestinations=@($g.Group | Select-Object -ExpandProperty DestinationAddress -Unique).Count}
}
Save-Csv 'WFP_Provider_Analysis.csv' $providerAnalysis
$serviceAnalysis = foreach ($g in ($allEventRows | Where-Object {$_.HostedServices} | Group-Object HostedServices,ProcessId,ProcessKind)) {
    $first=$g.Group | Select-Object -First 1
    [pscustomobject]@{ProcessId=$first.ProcessId; Process=$first.ProcessKind; HostedServices=$first.HostedServices; BlockEventCount=$g.Count; Providers=(($g.Group | Select-Object -ExpandProperty MatchedWfpProviderKey -Unique) -join ';'); Filters=(($g.Group | Select-Object -ExpandProperty MatchedWfpFilterName -Unique) -join ';')}
}
Save-Csv 'WFP_Service_Analysis.csv' $serviceAnalysis
$recommendations = foreach ($g in ($allEventRows | Group-Object ProcessKind,ProcessId,MatchedWfpProviderKey,MatchedWfpFilterName,DestinationAddress,DestinationPort,ProtocolName)) {
    $first=$g.Group | Select-Object -First 1
    $providerName = ''
    if ($first.MatchedWfpProviderKey) { $providerName = ($wfpFilters | Where-Object {$_.ProviderKey -eq $first.MatchedWfpProviderKey} | Select-Object -First 1).ProviderName }
    $actionText = 'Confirm the affected function actually fails at the event time. A WFP block alone is not proof of a fault. Do not add a broad allow rule.'
    if ($providerName -match '(?i)WireGuard') { $actionText += ' If unintended, inspect the WireGuard tunnel/kill-switch policy and interface scope; do not bypass it with a generic Windows Firewall allow rule.' }
    elseif ($providerName -match '(?i)Microsoft|MPSSVC') { $actionText += ' If unintended, identify the exact owning Windows Firewall rule/filter and adjust only that rule after exporting policy.' }
    elseif ($providerName) { $actionText += " If unintended, review the owning provider ($providerName) policy/configuration before changing Windows Firewall." }
    else { $actionText += ' Provider attribution is unavailable; collect a fresh WFP snapshot during a controlled reproduction before changing policy.' }
    [pscustomobject]@{Assessment='BLOCK_CONFIRMED_IMPACT_NOT_PROVEN'; EventCount=$g.Count; Process=$first.ProcessKind; ProcessId=$first.ProcessId; HostedServices=$first.HostedServices; ProviderKey=$first.MatchedWfpProviderKey; ProviderName=$providerName; FilterName=$first.MatchedWfpFilterName; Action=$first.MatchedWfpAction; Destination=$first.DestinationAddress; DestinationPort=$first.DestinationPort; Protocol=$first.ProtocolName; RecommendedNextStep=$actionText; AutoRemediation='NONE - read-only diagnostic'}
}
Save-Csv 'WFP_Remediation_Recommendations.csv' $recommendations
# Candidate-only conflict scan: exact same explicit executable + direction, opposite action.
$ruleDetailRows = New-Object 'System.Collections.Generic.List[object]'
foreach ($r in $rules) {
    $app=''; $proto=''; $remotePort=''; $remoteAddress=''
    try { $af=Get-NetFirewallApplicationFilter -AssociatedNetFirewallRule $r -ErrorAction SilentlyContinue | Select-Object -First 1; if ($af) {$app=[string]$af.Program} } catch {}
    try { $pf=Get-NetFirewallPortFilter -AssociatedNetFirewallRule $r -ErrorAction SilentlyContinue | Select-Object -First 1; if ($pf) {$proto=[string]$pf.Protocol; $remotePort=(@($pf.RemotePort) -join ',')} } catch {}
    try { $ad=Get-NetFirewallAddressFilter -AssociatedNetFirewallRule $r -ErrorAction SilentlyContinue | Select-Object -First 1; if ($ad) {$remoteAddress=(@($ad.RemoteAddress) -join ',')} } catch {}
    if ($app -and $app -notin @('Any','*')) { $ruleDetailRows.Add([pscustomobject]@{Name=$r.Name; DisplayName=$r.DisplayName; Enabled=$r.Enabled; Direction=$r.Direction; Action=$r.Action; Profile=$r.Profile; Program=$app; Protocol=$proto; RemotePort=$remotePort; RemoteAddress=$remoteAddress}) }
}
$conflicts = New-Object 'System.Collections.Generic.List[object]'
$groups = $ruleDetailRows | Group-Object { (($_.Program.ToLowerInvariant())+'|'+([string]$_.Direction).ToLowerInvariant()) }
foreach ($grp in $groups) {
    $allows=@($grp.Group | Where-Object {$_.Action -eq 'Allow' -and [string]$_.Enabled -eq 'True'})
    $blocks=@($grp.Group | Where-Object {$_.Action -eq 'Block' -and [string]$_.Enabled -eq 'True'})
    foreach ($a in $allows) { foreach ($b in $blocks) { $conflicts.Add([pscustomobject]@{CandidateType='Same explicit program and direction have enabled opposite actions'; Program=$a.Program; Direction=$a.Direction; AllowRule=$a.Name; AllowDisplayName=$a.DisplayName; BlockRule=$b.Name; BlockDisplayName=$b.DisplayName; AllowProtocol=$a.Protocol; BlockProtocol=$b.Protocol; AllowRemotePort=$a.RemotePort; BlockRemotePort=$b.RemotePort; Scope='Candidate only; Windows Firewall precedence, filters, profiles, addresses and provider ordering must be evaluated'}) } }
}
Save-Csv 'WFP_Policy_Conflicts.csv' $conflicts
Add-Line "System (PID 4) blocked events: $(@($targetEventRows | Where-Object { $_.ProcessKind -eq 'System' }).Count)"
Add-Line "svchost.exe blocked events: $(@($targetEventRows | Where-Object { $_.ProcessKind -eq 'svchost.exe' }).Count)"
Add-Line "Distinct process identities in block events: $(@($allEventRows | Select-Object -ExpandProperty ProcessKind -Unique).Count)"
Add-Line "All-process event records: $($allEventRows.Count)"
Add-Line "Provider analysis groups: $(@($providerAnalysis).Count)"
Add-Line "Service analysis groups: $(@($serviceAnalysis).Count)"
Add-Line "Policy conflict candidates (not proof of effective conflict): $($conflicts.Count)"
Add-Line "Events carrying Filter Origin: $(@($allEventRows | Where-Object { $_.FilterOrigin }).Count)"
Add-Line "Filter Origin firewall rule records: $($filterOriginRows.Count)"
if ($allEventRows.Count) {
    Add-Line ''
    Add-Line 'All-process block event counts by process image:'
    $allEventRows | Group-Object ProcessKind | Sort-Object Count -Descending | Select-Object -First 30 @{Name='Process';Expression={$_.Name}},Count | Format-Table -AutoSize | Out-String -Width 220 | ForEach-Object { Add-Line $_ }
    Add-Line ''
    Add-Line 'All-process block event counts by provider and filter:'
    $allEventRows | Group-Object MatchedWfpProviderKey,MatchedWfpFilterName,MatchedWfpAction | Sort-Object Count -Descending | Select-Object -First 30 Count,Name | Format-Table -AutoSize | Out-String -Width 260 | ForEach-Object { Add-Line $_ }
    Add-Line ''
    Add-Line 'Most recent all-process WFP block events:'
    $allEventRows | Sort-Object TimeCreated -Descending | Select-Object -First 40 TimeCreated,EventId,ProcessKind,ProcessId,HostedServices,Direction,DestinationAddress,DestinationPort,ProtocolName,FilterOrigin,InterfaceIndex,MatchedWfpProviderName,MatchedWfpLayerName,MatchedWfpSubLayerName,MatchedWfpFilterName,MatchedWfpAction,InterfaceAlias,CorrelationStatus | Format-Table -AutoSize | Out-String -Width 320 | ForEach-Object { Add-Line $_ }
} else {
    Add-Line 'No 5152/5157 block events were found in the selected Security log window.'
    Add-Line 'This does not prove that no blocks occurred: required audit subcategories may be disabled, events may have aged out, or the block may not have generated these audit events.'
}

# 8. Interface mapping for any Interface Index values from event rows
Add-Section '8. NETWORK INTERFACE MAPPING'
Save-Csv 'NetworkInterfaces.csv' $interfaceRows
if ($interfaceRows.Count) { $interfaceRows | Format-Table -AutoSize | Out-String -Width 220 | ForEach-Object { Add-Line $_ } }

# 9. Optional non-invasive connectivity checks (not used to attribute a WFP block)
Add-Section '9. BASIC CONNECTIVITY CHECKS'
if ($RunNetworkTests) {
    foreach ($target in @('1.1.1.1','8.8.8.8')) {
        try {
            $test = Test-NetConnection -ComputerName $target -Port 443 -WarningAction SilentlyContinue
            Add-Line "$target TCP/443: Success=$($test.TcpTestSucceeded); Interface=$($test.InterfaceAlias); Source=$($test.SourceAddress.IPAddressToString)"
        } catch { Add-Line "$target connectivity test failed: $($_.Exception.Message)" }
    }
} else { Add-Line 'Skipped by default to avoid generating extra traffic during WFP evidence collection. Use -RunNetworkTests to opt in.' }

# 10. Interpretation safeguards
Add-Section '10. INTERPRETATION AND LIMITATIONS'
Add-Line 'Priority of evidence:'
Add-Line '1. Filter Origin in event 5152/5157, when present, is the preferred attribution field.'
Add-Line '2. Interface Index identifies the interface associated with the audited drop, when present.'
Add-Line '3. FilterRTID-to-WFP-XML matching is a best-effort cross-check against a current-state snapshot.'
Add-Line '4. WFP runtime filter IDs can change; a mismatch does not prove the event is unrelated to the current rule set.'
Add-Line '5. svchost hosted-service mapping is current-at-collection-time. A historical PID may have exited or been reused.'
Add-Line '6. This release analyzes every process identity in the retrieved 5152/5157 event set; it is not limited to System or svchost.exe.'
Add-Line '7. No audit settings were enabled. If events are absent, a later controlled audit step may be needed with explicit approval.'
Add-Line 'A block event confirms enforcement at a WFP layer, not that the block is unwanted. Functional impact must be reproduced and verified.'
Add-Line 'Provider attribution is essential: WireGuard, Microsoft MPSSVC, and third-party providers are distinct policy owners.'
Add-Line 'Policy conflict rows are candidates only; WFP provider/sublayer ordering and filter conditions may change the effective result.'
Add-Line 'No firewall, audit, WFP, UWF, service, route, registry, VPN, or DNS configuration was modified by this diagnostic.'


# 11. Microsoft Unified Write Filter (UWF) diagnostics - READ ONLY
Add-Section '11. MICROSOFT UNIFIED WRITE FILTER (UWF) - READ ONLY'
Add-Line 'This section inspects Microsoft Unified Write Filter. It does not enable/disable UWF, protect/unprotect volumes, change exclusions, alter overlay thresholds, or enter/exit servicing mode.'
Add-Line 'UWF is a write-protection feature, not a network firewall. It redirects writes to protected volumes into a virtual overlay; when the overlay is exhausted, write operations can fail.'
Add-Line "UWF event lookback: $LookbackHours hour(s); maximum events per log: $MaxUwfEvents."

$uwfMgr = Join-Path $env:SystemRoot 'System32\uwfmgr.exe'
$script:UwfMgr = $uwfMgr
$script:UwfCommandRows = New-Object 'System.Collections.Generic.List[object]'
$uwfDetected = $false
$uwfFeatureState = 'Unknown / not queried'
$uwfFeatureOutput = @()
$uwfDism = Join-Path $env:SystemRoot 'System32\dism.exe'

# DISM Get-FeatureInfo is an inspection-only query. It does not install or enable UWF.
Add-Line 'UWF optional-feature state (DISM read-only query):'
if (Test-Path -LiteralPath $uwfDism) {
    try {
        $uwfFeatureOutput = @(& $uwfDism /Online /Get-FeatureInfo /FeatureName:Client-UnifiedWriteFilter /English 2>&1)
        $uwfDismExit = $LASTEXITCODE
        $uwfFeatureText = ($uwfFeatureOutput | ForEach-Object { [string]$_ }) -join "`r`n"
        if ($uwfFeatureText -match '(?im)^\s*State\s*:\s*Enabled\s*$') { $uwfFeatureState = 'Enabled' }
        elseif ($uwfFeatureText -match '(?im)^\s*State\s*:\s*Disabled\s*$') { $uwfFeatureState = 'Disabled' }
        elseif ($uwfFeatureText -match '(?im)^\s*State\s*:\s*Enable Pending\s*$') { $uwfFeatureState = 'Enable Pending' }
        elseif ($uwfFeatureText -match '(?im)^\s*State\s*:\s*Disable Pending\s*$') { $uwfFeatureState = 'Disable Pending' }
        elseif ($uwfDismExit -ne 0) { $uwfFeatureState = "DISM query failed (exit $uwfDismExit)" }
        Add-Line "DISM feature state: $uwfFeatureState (exit code $uwfDismExit)"
        foreach ($line in $uwfFeatureOutput) { Add-Line ([string]$line) }
        $uwfFeatureOutput | ForEach-Object { [string]$_ } | Set-Content -LiteralPath (Join-Path $script:OutDir 'UWF_OptionalFeature.txt') -Encoding UTF8
        if ($uwfFeatureState -eq 'Enabled' -or (Test-Path -LiteralPath $uwfMgr)) { $uwfDetected = $true }
    } catch {
        $uwfFeatureState = "DISM query exception: $($_.Exception.Message)"
        Add-Line $uwfFeatureState
    }
} else {
    $uwfFeatureState = 'DISM executable not found'
    Add-Line $uwfFeatureState
}
if (-not (Test-Path -LiteralPath (Join-Path $script:OutDir 'UWF_OptionalFeature.txt'))) {
    @('DISM feature query did not produce output.', "Feature state: $uwfFeatureState") | Set-Content -LiteralPath (Join-Path $script:OutDir 'UWF_OptionalFeature.txt') -Encoding UTF8
}

# Inspect the UWF WMI namespace and class availability without invoking any methods.
$uwfNamespace = 'root\standardcimv2\embedded'
$uwfWmiRows = New-Object 'System.Collections.Generic.List[object]'
$uwfWmiError = ''
try {
    $uwfClasses = @(Get-WmiObject -Namespace $uwfNamespace -List -ErrorAction Stop | Where-Object { $_.Name -like 'UWF_*' })
    foreach ($class in $uwfClasses) {
        $uwfWmiRows.Add([pscustomobject]@{
            Namespace=$uwfNamespace
            ClassName=$class.Name
            SuperClass=$class.__SUPERCLASS
            PropertyCount=@($class.Properties).Count
            MethodCount=@($class.Methods).Count
        })
    }
    if ($uwfWmiRows.Count -gt 0) { $uwfDetected = $true }
    Add-Line "UWF WMI provider classes found: $($uwfWmiRows.Count)"
} catch {
    $uwfWmiError = $_.Exception.Message
    Add-Line "UWF WMI namespace/classes unavailable: $uwfWmiError"
}
Save-Csv 'UWF_WMI_Classes.csv' $uwfWmiRows

# Inventory UWF-related kernel drivers and services; this is current-state evidence only.
$uwfDriverServiceRows = New-Object 'System.Collections.Generic.List[object]'
try {
    $uwfDrivers = @(Get-CimInstance -ClassName Win32_SystemDriver -ErrorAction Stop | Where-Object { $_.Name -match '(?i)uwf' -or $_.DisplayName -match '(?i)unified write|uwf' })
    foreach ($driver in $uwfDrivers) {
        $uwfDriverServiceRows.Add([pscustomobject]@{
            Kind='SystemDriver'; Name=$driver.Name; DisplayName=$driver.DisplayName
            State=$driver.State; Started=$driver.Started; StartMode=$driver.StartMode
            PathName=$driver.PathName; ProcessId=''
        })
    }
} catch { Add-Line "UWF driver inventory query failed: $($_.Exception.Message)" }
try {
    $uwfServices = @(Get-CimInstance -ClassName Win32_Service -ErrorAction Stop | Where-Object { $_.Name -match '(?i)uwf' -or $_.DisplayName -match '(?i)unified write|uwf' })
    foreach ($service in $uwfServices) {
        $uwfDriverServiceRows.Add([pscustomobject]@{
            Kind='Service'; Name=$service.Name; DisplayName=$service.DisplayName
            State=$service.State; Started=$service.Started; StartMode=$service.StartMode
            PathName=$service.PathName; ProcessId=$service.ProcessId
        })
    }
} catch { Add-Line "UWF service inventory query failed: $($_.Exception.Message)" }
Save-Csv 'UWF_DriversAndServices.csv' $uwfDriverServiceRows
Add-Line "UWF-related drivers/services found: $($uwfDriverServiceRows.Count)"

# Invoke only explicitly listed uwfmgr GET/GET-EXCLUSIONS commands. No mutating command is called.
function Invoke-UwfReadOnlyCommand {
    param(
        [Parameter(Mandatory=$true)][string]$Label,
        [Parameter(Mandatory=$true)][string[]]$Arguments
    )
    $outputLines = New-Object 'System.Collections.Generic.List[string]'
    $exitCode = $null
    $commandText = 'uwfmgr.exe ' + ($Arguments -join ' ')
    [void]$outputLines.Add("LABEL: $Label")
    [void]$outputLines.Add("COMMAND: $commandText")
    try {
        $nativeOutput = @(& $script:UwfMgr @Arguments 2>&1)
        $exitCode = $LASTEXITCODE
        foreach ($item in $nativeOutput) { [void]$outputLines.Add([string]$item) }
    } catch {
        [void]$outputLines.Add("Invocation failed: $($_.Exception.Message)")
    }
    [void]$outputLines.Insert(2, "EXIT CODE: $(if ($null -eq $exitCode) { 'not available' } else { $exitCode })")
    $fullText = $outputLines -join "`r`n"
    $script:UwfCommandRows.Add([pscustomobject]@{
        Label=$Label; Command=$commandText; ExitCode=$exitCode
        Output=(($outputLines | Select-Object -Skip 3) -join ' | ')
    })
    foreach ($line in $outputLines) { Add-Line $line }
    Add-Line ''
    return ,$fullText
}

$uwfOutputFiles = New-Object 'System.Collections.Generic.List[string]'
if (Test-Path -LiteralPath $uwfMgr) {
    $uwfDetected = $true
    Write-Host '[UWF] Collecting current/next-session configuration, volumes, overlay, exclusions and servicing state...' -ForegroundColor Yellow
    $uwfReadCommands = @(
        [pscustomobject]@{ Label='Global UWF configuration (current and next session)'; Arguments=@('get-config'); File='UWF_GetConfig.txt' },
        [pscustomobject]@{ Label='All volumes (current and next session)'; Arguments=@('volume','get-config','all'); File='UWF_Volumes.txt' },
        [pscustomobject]@{ Label='Overlay configuration (current and next session)'; Arguments=@('overlay','get-config'); File='UWF_OverlayConfig.txt' },
        [pscustomobject]@{ Label='Current overlay available space'; Arguments=@('overlay','get-available-space'); File='UWF_OverlayAvailableSpace.txt' },
        [pscustomobject]@{ Label='Current overlay consumption'; Arguments=@('overlay','get-consumption'); File='UWF_OverlayConsumption.txt' },
        [pscustomobject]@{ Label='File exclusions for all volumes (current and next session)'; Arguments=@('file','get-exclusions','all'); File='UWF_FileExclusions.txt' },
        [pscustomobject]@{ Label='Registry exclusions (current and next session)'; Arguments=@('registry','get-exclusions'); File='UWF_RegistryExclusions.txt' },
        [pscustomobject]@{ Label='UWF servicing configuration (current and next session)'; Arguments=@('servicing','get-config'); File='UWF_ServicingConfig.txt' }
    )
    foreach ($item in $uwfReadCommands) {
        $commandText = Invoke-UwfReadOnlyCommand -Label $item.Label -Arguments $item.Arguments
        $commandPath = Join-Path $script:OutDir $item.File
        $commandText | Set-Content -LiteralPath $commandPath -Encoding UTF8
        $uwfOutputFiles.Add($item.File)
    }
    Save-Csv 'UWF_ReadOnlyCommands.csv' $script:UwfCommandRows
} else {
    Add-Line "uwfmgr.exe not found at $uwfMgr. UWF command-line configuration collection skipped."
    'uwfmgr.exe not found; UWF commands were not run.' | Set-Content -LiteralPath (Join-Path $script:OutDir 'UWF_GetConfig.txt') -Encoding UTF8
}

Add-Line "UWF detected by feature, WMI provider or uwfmgr: $uwfDetected"
Add-Line "UWF DISM optional-feature state: $uwfFeatureState"
Add-Line "UWF WMI provider classes: $($uwfWmiRows.Count)"
Add-Line "UWF output files: $($uwfOutputFiles.Count)"

# Collect UWF event evidence. Microsoft documents overlay threshold events in System/uwfvol
# (IDs 1=warning, 2=critical, 3=back-to-normal), and UWF Admin/Operational channels
# for configuration/servicing errors and informational messages.
Add-Line 'UWF event-log evidence:'
$uwfEventRows = New-Object 'System.Collections.Generic.List[object]'
$uwfLogStatusRows = New-Object 'System.Collections.Generic.List[object]'
$uwfLogsToQuery = New-Object 'System.Collections.Generic.List[string]'
[void]$uwfLogsToQuery.Add('System')
try {
    $availableUwfLogs = @(Get-WinEvent -ListLog '*UnifiedWriteFilter*' -ErrorAction SilentlyContinue)
    foreach ($log in $availableUwfLogs) {
        if ($log.LogName -and -not $uwfLogsToQuery.Contains([string]$log.LogName)) {
            [void]$uwfLogsToQuery.Add([string]$log.LogName)
        }
    }
} catch { Add-Line "Could not enumerate UnifiedWriteFilter event channels: $($_.Exception.Message)" }
# Include documented channel names as explicit checks even if enumeration did not return them.
foreach ($knownLog in @('Microsoft-Windows-UnifiedWriteFilter/Admin','Microsoft-Windows-UnifiedWriteFilter/Operational')) {
    if (-not $uwfLogsToQuery.Contains($knownLog)) { [void]$uwfLogsToQuery.Add($knownLog) }
}
foreach ($logName in $uwfLogsToQuery) {
    $logExists = $false
    $logEnabled = $null
    try {
        $logInfo = Get-WinEvent -ListLog $logName -ErrorAction Stop
        $logExists = $true
        $logEnabled = [bool]$logInfo.IsEnabled
    } catch { }
    $foundEvents = @()
    $queryNote = ''
    if ($logExists -and ($logName -eq 'System' -or $logEnabled)) {
        try {
            if ($logName -eq 'System') {
                $foundEvents = @(Get-WinEvent -FilterHashtable @{ LogName='System'; ProviderName='uwfvol'; Id=@(1,2,3); StartTime=$since } -MaxEvents $MaxUwfEvents -ErrorAction Stop)
            } else {
                $foundEvents = @(Get-WinEvent -FilterHashtable @{ LogName=$logName; StartTime=$since } -MaxEvents $MaxUwfEvents -ErrorAction Stop)
            }
            if ($foundEvents.Count -eq $MaxUwfEvents) { $queryNote = "Reached per-log maximum ($MaxUwfEvents); older matching events may be omitted." }
        } catch {
            $queryNote = $_.Exception.Message
        }
    } elseif ($logExists -and -not $logEnabled) {
        $queryNote = 'Log exists but is disabled; it was not enabled by this diagnostic.'
    } else {
        $queryNote = 'Log not present or not accessible.'
    }
    $uwfLogStatusRows.Add([pscustomobject]@{
        LogName=$logName; Exists=$logExists; Enabled=$logEnabled
        EventsRetrieved=$foundEvents.Count; QueryNote=$queryNote
    })
    foreach ($eventRecord in $foundEvents) {
        $eventDataMap = Get-EventDataMap -EventRecord $eventRecord
        $eventDataText = (($eventDataMap.GetEnumerator() | Sort-Object Name | ForEach-Object { "$($_.Name)=$($_.Value)" }) -join '; ')
        $messageText = [string]$eventRecord.Message
        if ($messageText.Length -gt 6000) { $messageText = $messageText.Substring(0,6000) + ' ...[truncated]' }
        $uwfEventRows.Add([pscustomobject]@{
            TimeCreated=$eventRecord.TimeCreated; LogName=$logName
            ProviderName=$eventRecord.ProviderName; EventId=$eventRecord.Id
            Level=$eventRecord.Level; LevelDisplayName=$eventRecord.LevelDisplayName
            RecordId=$eventRecord.RecordId; MachineName=$eventRecord.MachineName
            TaskDisplayName=$eventRecord.TaskDisplayName; OpcodeDisplayName=$eventRecord.OpcodeDisplayName
            EventData=$eventDataText; Message=$messageText
        })
    }
}
Save-Csv 'UWF_Events.csv' $uwfEventRows
Save-Csv 'UWF_EventLog_Status.csv' $uwfLogStatusRows
Add-Line "UWF event records collected: $($uwfEventRows.Count)"
Add-Line "UWF event logs checked: $($uwfLogStatusRows.Count)"
foreach ($logStatus in $uwfLogStatusRows) {
    Add-Line ("{0}: Exists={1}; Enabled={2}; Events={3}; {4}" -f $logStatus.LogName,$logStatus.Exists,$logStatus.Enabled,$logStatus.EventsRetrieved,$logStatus.QueryNote)
}
if ($uwfEventRows.Count -gt 0) {
    Add-Line ''
    Add-Line 'Most recent UWF events:'
    $uwfEventRows | Sort-Object TimeCreated -Descending | Select-Object -First 40 TimeCreated,LogName,ProviderName,EventId,LevelDisplayName,Message | Format-Table -Wrap -AutoSize | Out-String -Width 260 | ForEach-Object { Add-Line $_ }
} else {
    Add-Line 'No matching UWF events were retrieved in the selected time window. This does not prove that UWF has never generated events; logs may be empty, disabled, unavailable, or outside the lookback window.'
}

$uwfSummaryPath = Join-Path $script:OutDir 'UWF_DIAGNOSTIC_SUMMARY.txt'
$uwfSummary = @(
    'UWF-DIAG Unified Write Filter summary (read-only)',
    "Generated: $((Get-Date).ToString('o'))",
    "Feature state: $uwfFeatureState",
    "UWF detected: $uwfDetected",
    "uwfmgr present: $(Test-Path -LiteralPath $uwfMgr)",
    "WMI classes found: $($uwfWmiRows.Count)",
    "Related driver/service records: $($uwfDriverServiceRows.Count)",
    "UWF events collected: $($uwfEventRows.Count)",
    '',
    'See UWF_GetConfig.txt, UWF_Volumes.txt, UWF_OverlayConfig.txt, UWF_OverlayConsumption.txt,',
    'UWF_OverlayAvailableSpace.txt, UWF_FileExclusions.txt, UWF_RegistryExclusions.txt and UWF_ServicingConfig.txt contain detailed command output.',
    'See UWF_Events.csv and UWF_EventLog_Status.csv for overlay warnings/errors and servicing/configuration events.',
    'See UWF_WMI_Classes.csv and UWF_DriversAndServices.csv for provider and driver/service detection.',
    'No UWF configuration was modified by this diagnostic.'
)
$uwfSummary | Set-Content -LiteralPath $uwfSummaryPath -Encoding UTF8
Write-Host "[UWF] Collection complete. WMI classes: $($uwfWmiRows.Count); events: $($uwfEventRows.Count)." -ForegroundColor Green


$reportPath = Join-Path $script:OutDir 'UWF-DIAG_Report.txt'
$script:Report | Set-Content -LiteralPath $reportPath -Encoding UTF8
[pscustomobject]@{
    Tool='UWF-DIAG'; Version='1.0.5'; Generated=(Get-Date).ToString('o')
    Computer=$env:COMPUTERNAME; Elevated=$isAdmin; LookbackHours=$LookbackHours
    AuditEvents=$events.Count; AllProcessEvents=$allEventRows.Count; SystemSvchostEvents=$targetEventRows.Count; WfpFilterRecords=$wfpFilters.Count; PolicyConflictCandidates=$conflicts.Count
    UwfDetected=$uwfDetected; UwfFeatureState=$uwfFeatureState; UwfEventLookbackHours=$LookbackHours; UwfMaxEventsPerLog=$MaxUwfEvents; UwfEventRecords=$uwfEventRows.Count; UwfWmiClasses=$uwfWmiRows.Count
    Report=$reportPath
} | ConvertTo-Json -Depth 4 | Set-Content -LiteralPath (Join-Path $script:OutDir 'RunMetadata.json') -Encoding UTF8

Write-Host ''
Write-Host 'UWF-DIAG v1.0.5 collection completed.' -ForegroundColor Green
Write-Host "Report: $reportPath" -ForegroundColor Cyan
Write-Host "All-process correlation: $(Join-Path $script:OutDir 'WFP_AllProcess_BlockCorrelation.csv')" -ForegroundColor Cyan
Write-Host 'No firewall, audit, WFP or UWF configuration was changed.'
try { Stop-Transcript | Out-Null } catch { }
try { Start-Process explorer.exe -ArgumentList "`"$script:OutDir`"" } catch { }
