# Read-only PowerShell parser check for UWF-DIAG v1.0.5
$scriptPath = Join-Path $PSScriptRoot 'UWF-DIAG_v1.0.5.ps1'
if (-not (Test-Path -LiteralPath $scriptPath)) {
    Write-Host "ERROR: Script not found: $scriptPath" -ForegroundColor Red
    exit 2
}
$tokens = $null
$errors = $null
[System.Management.Automation.Language.Parser]::ParseFile($scriptPath, [ref]$tokens, [ref]$errors) | Out-Null
if ($errors.Count -eq 0) {
    Write-Host 'No PowerShell syntax errors found.' -ForegroundColor Green
    exit 0
}
Write-Host "Found $($errors.Count) PowerShell parser error(s):" -ForegroundColor Red
foreach ($errorItem in $errors) {
    Write-Host "Line $($errorItem.Extent.StartLineNumber), column $($errorItem.Extent.StartColumnNumber): $($errorItem.Message)" -ForegroundColor Yellow
    Write-Host "Code: $($errorItem.Extent.Text)"
}
exit 1
