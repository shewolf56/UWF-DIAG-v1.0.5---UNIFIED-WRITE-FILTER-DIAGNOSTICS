@echo off
setlocal EnableExtensions
set "SCRIPT=%~dp0UWF-DIAG_v1.0.5.ps1"
if not exist "%SCRIPT%" (
    echo ERROR: UWF-DIAG_v1.0.5.ps1 was not found beside this launcher.
    pause
    exit /b 2
)

fltmc >nul 2>&1
if errorlevel 1 (
    echo Requesting Administrator privileges...
    powershell.exe -NoProfile -ExecutionPolicy Bypass -Command "Start-Process -FilePath '%~f0' -Verb RunAs"
    exit /b
)

powershell.exe -NoLogo -NoProfile -ExecutionPolicy Bypass -NoExit -File "%SCRIPT%"
endlocal
